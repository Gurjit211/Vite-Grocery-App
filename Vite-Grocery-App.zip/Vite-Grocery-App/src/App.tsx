import { useState } from "react";
import Header from "./components/Header";
import GroceryItem from "./components/Grocery";

function App() {
  const [groceryList, setGroceryList] = useState([
    { id: 1, name: "Apples", quantity: 5 },
    { id: 2, name: "Bananas", quantity: 3 },
    { id: 3, name: "Oranges", quantity: 4 },
    { id: 4, name: "Grapes", quantity: 2 },
    { id: 5, name: "Pineapples", quantity: 1 },
    { id: 6, name: "Mangoes", quantity: 6 },
    { id: 7, name: "Peaches", quantity: 2 },
    { id: 8, name: "Plums", quantity: 4 },
    { id: 9, name: "Cherries", quantity: 3 },
    { id: 10, name: "Strawberries", quantity: 5 },
  ]);

  const handleDelete = (id: number) => {
    setGroceryList((prevList) => prevList.filter((item) => item.id !== id));
  };

  return (
    <>
      <Header title="Grocery List" total={groceryList.length} />
      {groceryList.map((g) => (
        <GroceryItem
          key={g.id}
          id={g.id}
          name={g.name}
          quantity={g.quantity}
          onDelete={handleDelete}
        />
      ))}
    </>
  );
}

export default App;
