type HeaderProps = {
  title: string;
  total: number;        
};

// interface HeaderComponentProps {
//   title: string;       
//   total: number;
// }

function Header({title, total}: HeaderProps) {
  return (
    <header className="bg-gray-800 text-white p-4">
      <h1 className="text-2xl">{title} -  Total : {total}</h1>
    </header>
  );
}
export default Header;