type GroceryItemProps = {
  id: number;
  name: string;
  quantity: number;
  onDelete: (id: number) => void;
};

function GroceryItem({ id, name, quantity, onDelete }: GroceryItemProps) {
  return (
    <div className="grocery">
      <span className="grocery-name">
        <button
          className="remove-grocery"
          onClick={() => onDelete(id)}
        >
          X
        </button>
        {name}
      </span>{" "}
      - <span>{quantity}</span>
    </div>
  );
}

export default GroceryItem;
